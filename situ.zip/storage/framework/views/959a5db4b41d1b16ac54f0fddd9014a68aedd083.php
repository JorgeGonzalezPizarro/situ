<script src="/js/jquery-3.3.1.min.js"></script>

<?php $__env->startSection('content'); ?>

    <div class="col-lg-10 col-lg-offset-1">

        <h1><i class="fa fa-users"></i> Hola   <?php if(Sentinel::check()): ?> <?php echo e(Sentinel::getUser()->first_name); ?> <?php endif; ?>   </h1>

        <div class="table-responsive" style="overflow-x: hidden" >
            <table id="usuarios" class="mdl-data-table" cellspacing="0" width="100%">

                <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Fecha Límite</th>

                </tr>
                </thead>

                <tbody id="clickable">



                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="" style="cursor: pointer">
                            <td id="user"><?php echo e($user->first_name); ?></td>
                            <td id="user"><?php echo e($user->last_name); ?></td>
                            <td id="user" ><?php echo e($user->email); ?></td>
                            <td id="user" ><?php echo e($user->roles()->first()->slug); ?></td>

                            <?php if(($user->roles()->first()->slug=='Prof')|| ($user->roles()->first()->slug=='Inv')): ?>
                                <td id="prof">
                           <span  class="prof"> <?php echo e($user->invitado()->get()->first()->fecha_limite); ?></span>

                             <br>  <a href="#myModal2" data-toggle="modal" id="<?php echo e($user->invitado()->get()->first()->id); ?>" data-target="#myModal2">Cambiar Fecha </a></td>

                                <?php else: ?>
                                <td>  <?php echo e("Indefinido"); ?></td>
                                <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>
        </div>


    </div>
    <div class="modal fade" id="myModal2" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class='input-group date' id='datetimepicker2'>
                            <input name="fechaActualizar" id="fechaActualizar" type='text' class="form-control" />
                            <span class="input-group-addon">

                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                        </div>
                        <div class='input-group date' id='datetimepicker2'>
                            <button type="submit" id="botonActualizarFecha">Confirmar</button>

                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Bootstrap Date-Picker Plugin -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<?php $__env->stopSection(); ?>
<script>
    $(document).ready(function() {
        var myNodelist  =   document.getElementsByClassName("prof");

        var date= new Date();
        var array = $.map(myNodelist, function(value, index) {
            return [value];
        });
        var fechas;
        array.forEach(function (element){
                if(Date.parse(element.textContent) < date){
                    element.style.color="red";
                }else {

                }

        });
        console.log(  array);// Finds the closest row <tr>
    // Gets a descendent with class="nr"



        var url = "/Admin";
        var tr = $('#clickable');
        var table=$('#usuarios').DataTable({
                "scrollX": false,

                "language": {
                    "lengthMenu": "Ver _MENU_ Número de registros por página",
                    "zeroRecords": "No encontrado",
                    "info": "Página  _PAGE_ de  _PAGES_",
                    "infoEmpty": "No hay registros disponibles",
                    "infoFiltered": "(filtered from _MAX_ Total de usuarios)",
                    "paginate": {
                        "first":      "Primero",
                        "previous":   "Anterior",
                       "next":       "Siguiente",
                        "last":       "Último"
                    },
                    "search":         "Buscar &nbsp;:",

                }
            }


        );

        $('#myModal2').on('shown.bs.modal',function (e) {
            var id= e.relatedTarget.id;
            $("#botonActualizarFecha").on('click',function () {
                var fecha=document.getElementById("fechaActualizar");
                var fechaActualizar=fecha.value;
                var mensaje = confirm("¿Confirma cambiar la fecha");
                if (mensaje) {


                    $.ajax({
                        type: "get",
                        url: "<?php echo e(route('actualizarFechaAdmin')); ?>",
                        data: {
                            fecha: fechaActualizar,
                            id : id,
                        },
                        success: function (response) {
                            // console.log(response);

                          window.location.reload();
                        },
                        error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                            console.log(jqXHR);

                        }
                    });
                }


                else {

                }
            })


        });
        $("#datetimepicker2").datepicker({

            onSelect: function(date) {
                document.getElementById("endDate").disabled = false;



            }

        });



    function getFormattedDate(date) {
        var day = date.getDate();
        var month = date.getMonth() + 1;
        var year = date.getFullYear().toString().slice(2);
        return day + '-' + month + '-' + year;


    }



        $('#clickable').on('click','tr td#user', function () {

            var data = table
                .rows()
                .data();
            var cData = table.cell(this).data();
            var data = table.row( this ).data();
            //alert( 'You clicked on '+data[2]+'\'s row' );
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');


            $.ajax({
                   type:"get",
                url     : "<?php echo e(route('actualizarUsuario')); ?>",
                datatype:"json",
                encode  : true,
                  // url: url + '/' + 'actualizarUsuario'+ '/',
                   data: {
                       email: data[2],
                       _token: CSRF_TOKEN
                   },
                success: function(response){ // What to do if we succeed
                  window.location.href= "<?php echo e(url('Admin/usuario')); ?>"+"/"+response;
                    console.log(response);
                    

                },
                error: function(jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(JSON.stringify(jqXHR));
                    console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
                }
            });



        } );
    } );





</script>
    <!-- Scripts -->

<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
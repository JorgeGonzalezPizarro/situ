<!DOCTYPE html>
<html lang="en">
<head>
    <title>SITU , PLATAFORMA UNIVERSITARIA</title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="<?php echo e(asset('css/sb-admin.css')); ?>" rel="stylesheet">
    
    <script src="/js/jquery-3.3.1.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>

    <link rel="shortcut icon" href="<?php echo e(asset('imagenes/icono situ.ico')); ?>">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <!-- Latest compiled JavaScript -->
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    
    
    
    
    
    
    
    <link href="https://fonts.googleapis.com/css?family=Gugi|Lato:100,100i,300,300i,400,400i,700,700i|Roboto:300,300i,400,400i" rel="stylesheet">
    
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.material.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.1.0/material.min.css" rel="stylesheet" >
    
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
    
    

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

    <!-- (Optional) Latest compiled and minified JavaScript translation files -->
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Chosen -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/chosen.css')); ?>" rel="stylesheet">

    <!-- DataTables CSS -->


    <!-- Custom Fonts -->

    <!-- Chosen -->

    <!-- DataTables CSS -->




    
    
    


    



    <style>
        body {
            background:white;
            color: #444;
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;
            font-size: 13px;
            line-height: 1.4em;
            min-width: 600px;
        }
        h1,h2,h3,h4,h5{

            /*border-bottom: 1px solid white;*/
            font-family: 'Lato', sans-serif;
            font-style: oblique;
        }
        hr{
            border: transparent !important;
        }
        .navbar-inverse .navbar-nav > li > a {
            color: #ffffff;
            font-size: 16px;
        }
        #nav2 li {
            border-bottom: 1px solid white;
        }
        #nav2 li a{
        padding-bottom: 20px;
        border-bottom: 1px solid white;
            font-family: 'Lato', sans-serif;
            font-style: oblique;
        }
        .timeline-body  .pull-left{
            font-size: 16px;
        }
        .navbar-inverse {
            background-color: #003865;
            border-color: #ffffff;
        }
        .img-circle {
            border-radius: 50%;
            width: 70px;
        }
        .dropdown-menu > li > a:hover {
            background: #003865 !important;
            color: black;

        }
        pre {
            border: none;
            background: #fff;
            padding: 0;
        }
        /*.hljs {
            padding: 1.5em;
        }*/


        .navbar-header{
            display: none ;
        }
        .navbar-brand{display:none ;}
        pre code {
            border-radius: 20px;
            overflow: auto;
            word-wrap: normal;
            white-space: pre;
        }
        .list-group-item:last-child {
            margin-bottom: 0;
            border-bottom-right-radius: 4px;
            height: 50px;
            border-bottom-left-radius: 4px;
        }
        /* Panel */
        .panel-lightblue {
            border-color: #5bc0de;
        }

        .panel-lightblue > .panel-heading {
            border-color: #5bc0de;
            color: #fff;
            background-color: #5bc0de;
        }

        .panel-lightblue > a {
            color: #5bc0de;
        }

        .panel-lightblue > a:hover {
            color: #31b0d5;
        }
        ul.nav li.dropdown:hover ul.dropdown-menu {
            display: block;
        }
        ul.nav li.dropdown:hover ul.dropdown-menu {
            display: block;
        }
        .navbar{
            min-height: 60px;
        }
        .navbar-nav.navbar-center {
            position: absolute;
            left: 50%;
            transform: translatex(-50%);
        }
        .timeline > li > .timeline-panel {
            width: 100%;
            float: left;
            border: 1px solid #00386557;
            border-radius: 6px;
            padding: 20px;
            position: relative;
            -webkit-box-shadow: 0 1px 6px rgba(0, 0, 0, 0.175);
            box-shadow: 0 4px 11px rgba(0, 56, 101, 0.44);
            background: #5bc0de0a;
        }
        .timeline > li > .timeline-panel:after {
             display: none !important;
         }
        .timeline > li > .timeline-panel:before {
            display: none !important;
        }
        @media (max-width: 1200px) {
            .navbar-header {
                display: block !important;;
            }

            #wrapper {
                padding-left: 0px !important;
            }

            .navbar-header {
                float: none;
            }

            .navbar-brand {
                display: block;
                float: left;
            }

            .navbar-left, .navbar-right {
                float: none !important;
            }

            .navbar-left {
                display: none !important;
            }

            .navbar-nav > li > .dropdown-menu {
                margin-top: 0;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
                left: 100px;
                top: 10px;
            }

            #myimagen {
                display: none;
            }

            .navbar-inverse .navbar-nav > .open > a, .navbar-inverse .navbar-nav > .open > a:focus, .navbar-inverse .navbar-nav > .open > a:hover {
                background: #003865;
            }

            #navbarColor03 {
                display: block !important;
                padding-left: 10px;

            }

            .navbar-nav.navbar-center {
                position: relative;
            }

            .navbar-toggle {
                display: block;
            }

            .navbar-nav.navbar-center > li {
                padding: 0px !important;
                margin-left: 5px !important;
                /* transform: translatex(-50%); */
            }

            .navbar-collapse {
                border-top: 1px solid transparent;
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
            }

            .navbar-nav.navbar-center .fa {
                font-size: 20px !important;
            }

            .navbar-fixed-top {
                top: 0;
                border-width: 0 0 1px;
            }

            .navbar-collapse.collapse {
                display: none !important;
            }

            .navbar-nav {
                float: none !important;
                margin-top: 7.5px;
            }

            .navbar-nav > li {
                float: none;
            }

            .navbar-nav > li > a {
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .collapse.in {
                display: block !important;
            }

            .dropdown-menu > li > a:hover {
                background: #003865 !important;
                color: black;

            }

            .navbar-nav.navbar-center {
                float: left !important;
                left: 10% !important;
                transform: translatex(0%) !important;
            }

            .navbar-nav.navbar-center li {
                float: left;
                display: inline;
            }

            .nav.navbar-nav.side-nav {
                margin-top: 0px !important;
            }

            .navbar-toggle {
                position: relative;
                float: right;
                padding: 9px 10px;
                margin-top: 8px;
                margin-right: 15px;
                color: white;
                margin-bottom: 8px;
                background-color: #003865;
                background-image: none;
                border-color: white;
            }.navbar-inverse .navbar-toggle{
                             border-color: white;

                         }

        }
        .list-group-item {
            position: relative;
            display: block;
            padding: 10px 15px;
            margin-bottom: -1px;
            min-height: 55px;
            background-color: #fff;
            border: 1px solid #ddd;
        }

    </style>
    <?php echo $__env->yieldContent('css'); ?>


</head>

<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">


            <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>
                <a href="<?php echo e(route('misDatos')); ?>"  class="navbar-brand"><i class="far fa-smile"></i>



                    Mi perfil </a>
                    <a href="<?php echo e(route('alumnoDashboard')); ?>"  class="navbar-brand" style="display: inline;"><i class="fas fa-home"></i>


                        Panel de Control  </a>
                <a href="<?php echo e(route('invitar')); ?>" class="navbar-brand"><i class="fas fa-user-plus"></i>



                    Invitar  </a>
                <a href="<?php echo e(route('logout')); ?>" class="navbar-brand"  style="    float: right;"   > <span>Salir </span></a>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav3">
                    Nuevo

                </button>
                <?php if(Sentinel::check()   ): ?>

                    <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>


                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav2">
                            Hechos
                        </button>



                    <?php endif; ?>

                        <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>
                            <div class="collapse navbar-collapse navbar-ex1-collapse" id="nav3">
                                <ul class="nav navbar-nav side-nav"  style="  margin-top: 20px ;">

                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="" style="
    color: white;">
                                            <a href="<?php echo route('hechos', ['categoria'=>$categoria->categoria]); ?>" style="    color: white;">
                                                <i class="fas fa-plus-square"></i>
                                                <?php echo e($categoria->categoria); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                <?php endif; ?>

            <?php endif; ?>

        </div>


        <!-- Top Menu Items -->
        <div class="collapse navbar-collapse" style="  " id="bs-example-navbar-collapse-1">

            <div id="adminMenu" role="navigation" aria-label="Menú principal">
                <div id="adminmenuwrap" style="">
                    <ul class="nav navbar-nav navbar-left">

                        <li class="nav-item"  style="    right: 20px;">
                            <a class="nav-link" href="<?php echo e(url('Situ/public')); ?>">
                                <img style="     margin-top: -10px; width: 200px; float: left;"  id="myimagen" title="profile image" src="/imagenes/logo1.jpg" class="img-responsive" name="imagen">
                            </a>

                        </li>
                    </ul>
                    <ul style="font-family: 'Gugi', cursive;"  class="nav navbar-nav navbar-center">
                        <?php if(Sentinel::check()   ): ?>

                            <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>




                                <li sty class="dropdown">

                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">                                    <i class="fas fa-plus"></i>
                                       Nuevo <span class="caret"></span></a>
                                    <ul  style="    background: #003865c7;
    color: white;" class="dropdown-menu" id="menuNuevo">
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="" style="
    color: white;">
                                                <a href="<?php echo route('hechos', ['categoria'=>$categoria->categoria]); ?>" style="    color: white;">
                                                    <i class="fas fa-plus-square"></i>



                                                    <?php echo e($categoria->categoria); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li class="">
                                    <a href="<?php echo e(route('misDatos')); ?>"><i class="far fa-smile"></i>



                                        Mi perfil </a>

                                </li>
                                <li class="">
                                    <a href="<?php echo e(route('invitar')); ?>"><i class="fa fa-user-plus"></i>



                                        Invitar  </a>

                                </li>
                                <li class="">
                                    <a href="<?php echo e(url('Situ/public')); ?>"><img width="25"  src="/imagenes/icono situ.ico"/>



                                        Mi SITU  </a>

                                </li>
                                <li class="">

                                    <a style="padding: 10px;" target="_blank" href="<?php echo e(url('Situ/public/0/5/'.Sentinel::getUser()->id.'/cv')); ?>"><button type="button" class="btn btn-raised btn-secondary">CV</button></a>
                                </li>
                                <li class="">

                                <a style="padding: 10px;" target="_blank" href="<?php echo e(route('logAccesos')); ?>"><button type="button" class="btn btn-raised btn-secondary">LOGS ACCESOS</button></a>
                                </li>

                            <?php endif; ?>



                        <?php endif; ?>

                    </ul>
                    <ul class="nav navbar-nav navbar-center" style="text-align: center;">
                        <li>



                            <?php if(Sentinel::check() &&( Sentinel::inRole('Inv')  ) ): ?>

                                <div style=" text-align: center;  color: white; height: auto; margin:0 auto;">
                                     <h2>Bienvenido al portal  de <?php echo e($alumno->first_name); ?>  <?php echo e($alumno->last_name); ?></h2>
                                </div>

                               <?php elseif(Sentinel::check() &&( Sentinel::inRole('Prof')  ) ): ?>

                                <div style=" height: auto; margin:0 auto;">
                                    <h3 style="text-align: center; color:white;" class="form-signin-heading"> ¡ Bienvenido al Portal de Trayectoria Universitaria ! </h3>
                                    <hr class="colorgraph"><br>                                </div>
                            <?php endif; ?>
                        </li></ul>
                            <ul class="nav navbar-nav navbar-right">

                                <li class="dropdown">
                                    <?php if(Sentinel::check()): ?>

                                        <?php $otros_datos=json_decode(Sentinel::getUser()->otros_datos,true);?>
                                        <div class="avatar" style="    width: 250px; float: left; margin-right: 5px;">
                                            <img style=" width: 50px;height: 50px; float: left;"  id="myimagen" title="profile image" src="<?php echo $otros_datos['img']; ?>" class="img-circle img-responsive" name="imagen">
                                            <a href="#" class="dropdown-toggle" style="    padding: 20px; padding-top: 100px; position: relative;top: 10px;" data-toggle="dropdown"> <span><?php echo e(Sentinel::getUser()->first_name); ?> </span><b class="caret"></b></a>

                                        </div>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                    <?php endif; ?>
                                        <ul class="dropdown-menu" style=" margin-right: 20px;   background: #003865c7;
    ">          
                                        <?php if(Sentinel::check()   ): ?>

                                            <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>




                                            <?php endif; ?>
                                            <li>
                                                <a  style="  background: #003865c7 !important; ;color: white;" href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                                                    Salir</a>

                                            </li>

                                        <?php else: ?>

                                        <?php endif; ?>
                                    </ul>
                                </li>
                                </li>
                            </ul>
                    </ul>

                </div>
            </div>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav2">
                    <span class="sr-only">Toggle navigation</span>


                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>
        </div>

        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class="collapse navbar-collapse navbar-ex1-collapse" id="nav2">
            <ul class="nav navbar-nav side-nav"  style="  margin-top: 25px ;">
                <?php if(Sentinel::check() && Sentinel::inRole('Admin')): ?>
                    <li class="">
                        <a href="<?php echo e(url('Admin/adminDashboard')); ?>"><i class="fas fa-home"></i>

                            Panel de control</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('nuevoUsuario')); ?>"><i class="fas fa-user-plus"></i>

                            Crear Usuario</a>
                    </li>
                    <li class="">
                        <a href=<?php echo e(route('crearEtiqueta')); ?>><i class="fas fa-tags"></i>

                            CrearEtiqueta</a>
                    </li>
                <?php elseif(Sentinel::check() && Sentinel::inRole('Alu')): ?>
                    <li class="">
                        <a href="<?php echo e(route('alumnoDashboard')); ?>"><i class="fas fa-home"></i> Inicio</a>
                    </li>

                    <li class="">
                        <a href="<?php echo route('calificaciones'); ?>"><i class="fas fa-tasks"></i>Calificaciones</a>
                    </li>
                    <li class="">
                        <a href="<?php echo url('Situ/public/0/5'); ?>"><i class="fas fa-briefcase"></i>

                            Portfolio Profesional</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('trabajos'); ?>"><i class="fas fa-graduation-cap"></i>

                            Trabajos Academicos</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('recuerdosAll'); ?>"><i class="fas fa-bookmark"></i>

                            Recuerdos</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('proyectosInvestigacionAll'); ?>"><i class="fas fa-newspaper"></i>

                            Proyectos</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('hechos', ['categoria'=>"Frases Guia"]); ?>">
                            <i class="fas fa-quote-left"></i>
                            Mis Frases</a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>

        <!-- /.navbar-collapse -->
    </nav>

    <div id="page-wrapper">

        <div class="container-fluid">

            <?php if(Session::has('permission')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('permission')); ?>

                </div>
            <?php endif; ?>
        <!-- /.content -->
            <?php echo $__env->yieldContent('content'); ?>

        </div><!-- /.container-fluid -->

    </div><!-- /#page-wrapper -->



    <!-- Bootstrap Core JavaScript -->

    <!-- Select Chosen -->


    <!-- DataTables JavaScript -->
</div>







</body>
<script src="http://harvesthq.github.io/chosen/chosen.jquery.js"></script>
<script>
    $(function() {
        $('.chosen-select').chosen({max_selected_options: 3});
        $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
    });
</script>
</html>
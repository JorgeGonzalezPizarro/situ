<script src="/js/jquery-3.3.1.min.js"></script>

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 col-lg-offset-0">

        <div class='col-md-12' style="    margin-top: 30px; float: left;">
            <div class="col-md-9">
                <?php echo Form::textarea('contenido', Input::old('contenido') , ['id'=>'contenido','placeholder'=>'Frase guía','style'=>'    margin-top: 0px; margin-bottom: 0px;width: 100%;height: 70px;']); ?>



            </div>
            <div class="col-md-3" style="margin-top: 30px">
                <?php echo Form::button('Guardar', array('class'=>'btn btn-info ' ,'id'=>'fraseButton' , 'style=""')); ?></td>

            </div>
            <div class="clearfix"></div>
            <br>
            <br>
            <br>

            <div class="table-responsive" style="overflow-x: hidden">
                <table id="hechos" class="mdl-data-table" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Fecha de creación</th>
                        <th>Contenido</th>
                        <th>Fecha del hecho</th>
                        <th>Categoria</th>
                        <th>Etiquetas</th>
                        <th>Acceso</th>

                    </tr>
                    </thead>

                    <tbody id="clickable">


                    <?php $__currentLoopData = $hechos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="" style="cursor: pointer">
                            <td id="id"><?php echo e($hecho->id); ?></td>
                            <td id="click"><?php echo e($hecho->created_at); ?></td>
                            <td id="descripcion"><?php echo str_limit($hecho->contenido,50,'...' ); ?></td>
                            <td id="click"><?php echo e($hecho->fecha_inicio); ?></td>
                            <td id="click"><?php echo e($hecho->getCategoria()->get()->first()->categoria); ?></td>

                            <td> <?php $__currentLoopData = $hecho->getEtiqueta()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $etiq->etiqueta_id .' | '; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>




                            <?php ($publico = ["publico" => "publico",
                            "privado" => "privado"]); ?>
                            
                            
                            <td id="seleccionar">
                                <?php ( $checked=""); ?>
                                <?php $__currentLoopData = $publico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $public): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($hecho->publico==$public): ?>

                                        <?php ($checked='checked'); ?>
                                    <?php elseif($hecho->publico==$public): ?>

                                        <?php ($checked='checked'); ?>
                                        <?php else: ?>
                                        <?php ($checked=''); ?>
                                    <?php endif; ?>
                                    <?php echo e($public); ?> <?php echo Form::checkbox( $public,$public,$checked,['class'=>'checkbox']); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            </div>

        <div class="col-lg-8">

            <!-- Title -->

            <!-- Author -->



            <hr>


            <div class="panel-body">

                <div class="row">
                    <ul class="list-group">


                        <li class="list-group-item text-muted"style=" text-align: center ;color: #31708f;
    background-color: #d9edf7;
    border-color: #bce8f1;     font-size: 18px;"  contenteditable="false">Mis frases</li>

                    </ul>
                    <?php if(count($frases)>0): ?>

                    <?php $__currentLoopData = $frases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <ul class="timeline">
                        <li>
                                <blockquote class="quote-card">
                                    <p style="font-size: 22px;
    font-family: 'Harlow Solid Italic';
    font-style: italic;
    margin-top: 20px;
    margin-left: 20px;">"<?php echo e($hecho->contenido); ?>"<span> por <?php echo e($user-> first_name); ?></span></p>

                                    </p>
                                    <small><i class="glyphicon glyphicon-time"></i> <?php echo e($hecho->created_at); ?></small>

                                    </blockquote>
                        </li>


                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <ul class="timeline">
                            <li>
                                <div class="timeline-heading">
                                    <p><small class="text-muted"> </small></p>
                                </div>
                                <div class="timeline-body">
                                    <div class="alert alert-warning"><a href="<?php echo e(route('hechos', ['categoria'=>"Frases Guia"])); ?>" >Comienza añadiendo tus frases preferidas a la plataforma !</a>
                                    </div>


                                </div>
                            </li>


                        </ul>
                    <?php endif; ?>
                </div>
            </div>



        </div>


        <div class="col-lg-4">

            <!-- Title -->

            <!-- Author -->



            <hr>


            <div class="panel-body">

                <div class="row">
                    <div class="card my-4">
                        <div class="panel panel-info" style="color: white;
    background: #003865;
    margin: 0px;
    text-align: center;margin:0px; padding-left: 0;
    margin-bottom: 20px;">
                            <div class="panel-body" style="padding: 10px;">
                                INVITADOS
                            </div>
                        </div>
                        <?php if(count($invitados)>0): ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item text-right"><span class="pull-left"><strong
                                                            class="">Invitado</strong></span>
                                                <a id="popoverOption" class="btn" href="<?php echo e(route('invitar')."#table"); ?>" data-content="Ver detalles" rel="popover" data-placement="left" data-original-title="<?php echo e($invitado->getUsuario()->get()->first()->first_name ." " .$invitado->getUsuario()->get()->first()->last_name); ?>">
                                                    <?php echo e($invitado->getUsuario()->get()->first()->first_name ." " .$invitado->getUsuario()->get()->first()->last_name); ?></a>
                                            </li>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                    </div>
                </div>
                            <?php else: ?>
                            <ul class="timeline">
                                <li>
                                        <div class="timeline-heading">
                                            <p><small class="text-muted"> </small></p>
                                        </div>
                                        <div class="timeline-body">
                                            <div class="alert alert-warning"><a href="<?php echo e(route('invitar')); ?>" >Aun no tienes invitados ! Comienza a invitar para dar a conocer tu perfil </a>
                                                </div>



                                    </div>
                                </li>


                            </ul>
                        <?php endif; ?>
            </div>


                </div>

        </div>

    </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<script>

    $(document).ready(function () {


        $('#popoverData').popover();
        $('#popoverOption').popover({ trigger: "hover" });


        var url = "/Alumno";

        var tr = $('#clickable');
        var table = $('#hechos').DataTable({


            "scrollX": false,

            "language": {
                "lengthMenu": "Ver _MENU_ Número de registros por página",
                "zeroRecords": "No encontrado",
                "info": "Página  _PAGE_ de  _PAGES_",
                "infoEmpty": "No hay registros disponibles",
                "infoFiltered": "(filtered from _MAX_ Total de usuarios)",
                "paginate": {
                    "first": "Primero",
                    "previous": "Anterior",
                    "next": "Siguiente",
                    "last": "Último"
                },
                "search": "Buscar &nbsp;:",

            }
        });
        $('#clickable').on('click', '#click', function () {

            var data = table
                .rows()
                .data();
            var cData = table.cell(this).data();
            var data = table.row(this).data();
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');


            $.ajax({
                type: "get",
                url: "<?php echo e(route('showHecho')); ?>",
                datatype: "json",
                encode: true,
                data: {
                    id: data[0],
                    _token: CSRF_TOKEN
                },
                success: function (response) {
                    window.location.href = "<?php echo e(url('Situ/public')); ?>" + "/" + response['id'] + "/"+response['categoria_id'];
                    console.log("aa+ " + response);

                },
                error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(JSON.stringify(jqXHR));
                    console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
                }
            });


        });
        $('#fraseButton').on('click', function () {
            var data = $('#contenido').val();
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

            $.ajax({
                type: "post",
                url: "<?php echo e(route('fraseguia')); ?>",
                encode: true,
                data: {
                    contenido: data,
                    categoria_id: 3,
                    _token: CSRF_TOKEN

                },
                success: function (response) { // What to do if we succeed
                        window.location.href = "<?php echo e(route('alumnoDashboard')); ?>";

                },
                error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(JSON.stringify(jqXHR));
                    console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
                }
            });


        });
    });

</script>
<script>
    $(document).ready(function () {

        var table = $('#hechos').DataTable();
        var data = table
            .rows()
            .data();
        var cData = table.cell(this).data();
        var data = table.row(this).data();
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');


        $('.checkbox').click(function () { checkedState = $(this).attr('checked');
            $(this).parent('td').children('.checkbox:checked').each(function () {
                $(this).attr('checked', false);
            });
            var hecho=($(this).parent('td').parent('tr').find('#id').text());
            // $(this).attr('checked', checkedState);
            var mensaje = confirm("¿Confirma cambiar el nivel de acceso?");
            if (mensaje) {


                $.ajax({
                    type: "post",
                    url: "<?php echo e(route('actualizaAcceso')); ?>",
                    encode: true,
                    data: {
                        hecho: hecho,
                        _token: CSRF_TOKEN

                    },
                    success: function (response) {
                        window.location.reload();
                    },
                    error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                        window.location.reload();

                    }
                });
            }


            else {

            }
        });

        });



</script>


<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-lg-10 col-lg-offset-1">

        <h1><i class="fa fa-users"></i> Hola   <?php if(Sentinel::check()): ?> <?php echo e(Sentinel::getUser()->first_name); ?> <?php endif; ?>   </h1>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">

                <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Date/Time Added</th>
                    <th></th>
                </tr>
                </thead>

                <tbody>
                
                    <tr>
                        <?php if(Sentinel::check() ): ?>
                            <td><?php echo e(Sentinel::getUser()->name.' ' .Sentinel::getUser()->last_name); ?></td>
                            <td><?php echo e(Sentinel::getUser()->name.' ' .Sentinel::getUser()->last_name); ?></td>
                        <?php endif; ?>


                </tbody>

            </table>
        </div>

        <a href="/register" class="btn btn-success">Add User</a>

    </div>

<?php $__env->stopSection(); ?>

</div>

    <!-- Scripts -->


<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
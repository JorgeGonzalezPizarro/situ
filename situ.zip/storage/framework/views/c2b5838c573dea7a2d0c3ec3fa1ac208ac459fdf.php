<?php $__env->startSection('content'); ?>
    <div class = "container">
        <div class="wrapper">
            <div class="panel-heading">
                <div class="panel-title text-center">
                    <h1 class="title">Actualizar</h1>
                    <hr />
                </div>
            </div>
            <?php if(Session::has('message')): ?>
                <div class="alert alert-<?php echo e((Session::get('status')=='error')?'danger':Session::get('status')); ?> " alert-dismissable fade in id="sessions-hide">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong><?php echo e(Session::get('status')); ?>!</strong> <?php echo Session::get('message'); ?>

                </div>
            <?php endif; ?>
            
            

            
                
                
                    
                        
                        
                    
                    
                
            
            
                
                
                    
                        
                        
                    
                    
                
            
            
                
                
                    
                        
                        
                    
                    
                
            

            
                
                
                    
                        
                        
                    
                    
                
            

            
                
                
                    
                        
                        

                    
                    
                
            

            
                
                
                    
                        
                        

                    
                    
                
            
            

            
                
                    
                        

                        
                        
                    
                    

                
            
            <div class="form-group  <?php echo e($errors->has('password') ? 'has-error' : ''); ?> ">
                <button class="btn btn-primary btn-lg btn-block register-button" type="submit" >Register</button>

            </div>
            <div class="login-register">
                <a href="<?php echo e(url('login')); ?>">Login</a>
                <?php if($errors->has('global')): ?>
                    <span class="help-block danger">
                        <strong style="color:red" ><?php echo e($errors->first('global')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>SITU , PLATAFORMA UNIVERSITARIA</title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="<?php echo e(asset('css/sb-admin.css')); ?>" rel="stylesheet">
    
    <script src="/js/jquery-3.3.1.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Gugi|Lato:100,100i,300,300i,400,400i,700,700i|Roboto:300,300i,400,400i" rel="stylesheet">
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <!-- Latest compiled JavaScript -->
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    
    
    
    
    
    
    

    
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.material.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.1.0/material.min.css" rel="stylesheet" >
    
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
    
    

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

    <!-- (Optional) Latest compiled and minified JavaScript translation files -->
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Chosen -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/chosen.css')); ?>" rel="stylesheet">

    <link rel="shortcut icon" href="<?php echo e(asset('imagenes/icono situ.ico')); ?>">



    <style>
        body {
            background: #FAFAFA;
            color: #444;
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;
            font-size: 13px;
            line-height: 1.4em;
            min-width: 600px;
        }
        .navbar-inverse .navbar-nav > li > a {
            color: #ffffff;
            font-size: 16px;
        }
        .navbar-inverse {
            background-color: #003865;
            border-color: #ffffff;
        }
        .img-circle {
            border-radius: 50%;
            width: 70px;
        }
        .dropdown-menu > li > a:hover{
            background: white;
            color: black;
        }
        .dropdown-menu > li > a{
            color: white;
        }
        pre {
            border: none;
            background: #fff;
            padding: 0;
        }
        /*.hljs {
            padding: 1.5em;
        }*/


        .navbar-header{
            display: none ;
        }
        .navbar-brand{display:none ;}
        pre code {
            border-radius: 20px;
            overflow: auto;
            word-wrap: normal;
            white-space: pre;
        }
        .list-group-item:last-child {
            margin-bottom: 0;
            border-bottom-right-radius: 4px;
            height: 50px;
            border-bottom-left-radius: 4px;
        }
        /* Panel */
        .panel-lightblue {
            border-color: #5bc0de;
        }

        .panel-lightblue > .panel-heading {
            border-color: #5bc0de;
            color: #fff;
            background-color: #5bc0de;
        }

        .panel-lightblue > a {
            color: #5bc0de;
        }

        .panel-lightblue > a:hover {
            color: #31b0d5;
        }
        ul.nav li.dropdown:hover ul.dropdown-menu {
            display: block;
        }
        ul.nav li.dropdown:hover ul.dropdown-menu {
            display: block;
        }
        .navbar{
            /*min-height: 60px;*/
        }
        #nav2 li {
            border-bottom: 1px solid white;
        }
        #nav2 li a{
            padding-bottom: 20px;
            border-bottom: 1px solid white;
            font-family: 'Lato', sans-serif;
            font-style: oblique;
        }
        .navbar-nav.navbar-center {
            position: absolute;
            left: 50%;
            transform: translatex(-50%);
        }
        .timeline > li > .timeline-panel {
            width: 90%;
            float: left;
            border: 1px solid #999999;
            border-radius: 10px;
            padding: 20px;
            position: relative;
            -webkit-box-shadow: 0 1px 6px rgba(0, 0, 0, 0.175);
            box-shadow: 0 1px 6px rgba(0, 0, 0, 0.175);
        }
        @media (max-width: 1200px) {
            .navbar-header{
                display: block !important; ;
            }
            #wrapper {
                padding-left: 0px !important;
            }
            .navbar-header {
                float: none;
            }

            .navbar-brand {
                display: block;
            }

            .navbar-left, .navbar-right {
                float: none !important;
            }

            .navbar-left {
                display: none !important;
            }

            .navbar-nav > li > .dropdown-menu {
                margin-top: 0;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
                left: 100px;
                top: 10px;
            }

            #myimagen {
                display: none;
            }
            .navbar-inverse .navbar-nav > .open > a{
                background: #003865;
            }
            .navbar-nav.navbar-center {
                position: relative;

                /* transform: translatex(-50%); */
            }
            .navbar-nav.navbar-center >li {
                padding: 0px !important;
                margin-right: 5px !important;
                /* transform: translatex(-50%); */
            }
            .navbar-toggle {
                display: block;
            }
            .navbar-inverse .navbar-nav > .open > a, .navbar-inverse .navbar-nav > .open > a:focus, .navbar-inverse .navbar-nav > .open > a:hover{
                background: #003865;
            }
            .navbar-collapse {
                border-top: 1px solid transparent;
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
            }
            #navbarColor03{
                display: block !important;
                padding-left: 10px;
            }
            .navbar-fixed-top {
                top: 0;
                border-width: 0 0 1px;
            }

            .navbar-collapse.collapse {
                display: none !important;
            }

            .navbar-nav {
                float: none !important;
                margin-top: 7.5px;
            }

            .navbar-nav > li {
                float: none;
            }
            hr{
                border: transparent !important;
            }
            .navbar-nav > li > a {
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .collapse.in {
                display: block !important;
            }

            .navbar-nav.navbar-center {
                float: left !important;
                left: 10% !important;
                transform: translatex(0%) !important;
            }

            .navbar-nav.navbar-center li {
                float: left;
                display: inline;
            }
            .navbar-brand {
                display: block;
                float: right;
            }
            .nav.navbar-nav.side-nav{
                margin-top: 0px !important;
            }
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>

    <?php echo $__env->yieldContent('scripts'); ?>


</head>

<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav2">

                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
                <?php if(Sentinel::check()): ?>
                  <a href="<?php echo e(route('logout')); ?>" class="navbar-brand"     > <span>Salir </span></a>
                <ul class="nav navbar-nav navbar-center">
                    <?php if(Sentinel::check()   ): ?>

                        <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>



                            <li class="dropdown" style="padding: 10px;">

                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-plus"></i>
                                    Nuevo <span class="caret"></span></a>
                                <ul class="dropdown-menu" style="    padding: 5px;
    background: #003865d6;
    color: white;">
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class=""    style="
    padding: 10px;
    ">
                                            <a href="<?php echo route('hechos', ['categoria'=>$categoria->categoria]); ?>"><i class="fas fa-plus-square"></i>

                                                <?php echo e($categoria->categoria); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>

                            <li class="">
                                <a href="<?php echo e(route('misDatos')); ?>"><i class="far fa-smile"></i>



                                    Mi perfil </a>

                            </li>
                            <li class="">
                                <a href="<?php echo e(route('invitar')); ?>"><i class="fas fa-user-plus"></i>



                                    Invitar  </a>

                            </li>

                        <?php endif; ?>



                    <?php endif; ?>

                </ul>
                <?php endif; ?>

        </div>


        <!-- Top Menu Items -->
        <div class="collapse navbar-collapse" style=" " id="bs-example-navbar-collapse-1">

            <div id="adminMenu" role="navigation" aria-label="Menú principal">
                <div id="adminmenuwrap" style="">
                    <ul class="nav navbar-nav navbar-left">
                        <li class="nav-item"  style="    right: 20px;">
                            <a style="  font-family: 'Playfair Display', serif;
    font-style: italic;" class="nav-link" href="<?php echo e(url('Situ/public')); ?>">
                                <img style="     margin-top: -10px; width: 200px; float: left;"  id="myimagen" title="profile image" src="/imagenes/logo1.jpg" class="img-responsive" name="imagen">
                            </a>

                        </li>
                    </ul>
                        <ul style="    font-family: 'Gugi', cursive;" class="nav navbar-nav navbar-center">
                            <?php if(Sentinel::check()   ): ?>

                                <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>



                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-plus"></i>
                                            Nuevo <span class="caret"></span></a>
                                        <ul class="dropdown-menu" style=" padding: 5px;
    background: #003865d6;
    color: white;">
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="" style="
                                                    padding: 5px;
                                                    ">
                                                    <a style="" href="<?php echo route('hechos', ['categoria'=>$categoria->categoria]); ?>">
                                                        <i class="fas fa-plus-square"></i>
                                                        <?php echo e($categoria->categoria); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>

                                    <li class="">
                                        <a href="<?php echo e(route('misDatos')); ?>"><i class="far fa-smile"></i>



                                            Mi perfil </a>

                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(route('invitar')); ?>"><i class="fas fa-user-plus"></i>



                                            Invitar  </a>

                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(url('Situ/public')); ?>"><img width="25"  src="/imagenes/icono situ.ico"/>



                                            Mi SITU  </a>

                                    </li>
                                <?php endif; ?>



                            <?php endif; ?>

                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li>



                    <?php if(Sentinel::check() &&( Sentinel::inRole('Inv') ||  Sentinel::inRole('Prof') ) ): ?>

                        <div style="width:600px; height: auto; margin:0 auto;">
                            <ul class="nav navbar-nav ">
                                <li ><h2>Bienvenido al portal  de <?php echo e($alumno->getUsuario()->get()->first()->first_name); ?>  <?php echo e($alumno->getUsuario()->get()->first()->last_name); ?></h2></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <?php if(Sentinel::check()): ?>

                                <?php $otros_datos=json_decode(Sentinel::getUser()->otros_datos,true);?>
                                <div class="avatar" style="    width: 250px; float: left; margin-right: 5px;">
                                    <img style=" width: 50px;height: 50px; float: left;"  id="myimagen" title="profile image" src="<?php echo $otros_datos['img']; ?>" class="img-circle img-responsive" name="imagen">
                                    <a href="#" class="dropdown-toggle" style="    padding: 20px; padding-top: 100px; position: relative;top: 10px;" data-toggle="dropdown"> <span><?php echo e(Sentinel::getUser()->first_name); ?> </span><b class="caret"></b></a>

                                </div>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>">Login</a>
                            <?php endif; ?>
                            <ul class="dropdown-menu">
                                
                                <?php if(Sentinel::check()   ): ?>

                                    <?php if(Sentinel::check() && Sentinel::inRole('Alu')): ?>



                                    <?php endif; ?>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                                            Salir</a>

                                    </li>

                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                     </li>
                    </ul>
                    </ul>

                </div>
            </div>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav2">
                    <span class="sr-only">Toggle navigation</span>


                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>
        </div>

        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class="collapse navbar-collapse navbar-ex1-collapse" id="nav2">
            <ul class="nav navbar-nav side-nav"  style="  margin-top: 20px ;">
                <?php if(Sentinel::check() && Sentinel::inRole('Admin')): ?>
                    <li class="">
                        <a href="<?php echo e(url('Admin/adminDashboard')); ?>"><i class="fa fa-fw fa-dashboard"></i> Panel de control</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('nuevoUsuario')); ?>"><i class="fa fa-fw fa-dashboard"></i> Crear Usuario</a>
                    </li>
                    <li class="">
                        <a href=<?php echo e(route('crearEtiqueta')); ?>><i class="fa fa-fw fa-dashboard"></i> CrearEtiqueta</a>
                    </li>
                <?php elseif(Sentinel::check() && Sentinel::inRole('Alu')): ?>
                    <li class="">
                        <a href="<?php echo e(route('alumnoDashboard')); ?>"><i class="fas fa-home"></i> Inicio</a>
                    </li>

                    
                        <li class="">
                            <a href="<?php echo route('calificaciones'); ?>"><i class="fas fa-tasks"></i>Calificaciones</a>
                        </li>
                    <li class="">
                        <a href="<?php echo url('Situ/public/0/5'); ?>"><i class="fas fa-briefcase"></i>

                            Portfolio Profesional</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('trabajos'); ?>"><i class="fas fa-graduation-cap"></i>

                            Trabajos Academicos</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('recuerdosAll'); ?>"><i class="fas fa-bookmark"></i>

                            Recuerdos</a>
                    </li>
                    <li class="">
                        <a href="<?php echo route('proyectosInvestigacionAll'); ?>"><i class="fas fa-newspaper"></i>

                            Proyectos</a>
                    </li>
                    

                <?php endif; ?>
            </ul>
        </div>

        <!-- /.navbar-collapse -->
    </nav>

    <div id="page-wrapper">

        <div class="container-fluid">

            <?php if(Session::has('permission')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('permission')); ?>

                </div>
            <?php endif; ?>
        <!-- /.content -->
            <?php echo $__env->yieldContent('content'); ?>

        </div><!-- /.container-fluid -->

    </div><!-- /#page-wrapper -->



    <!-- Bootstrap Core JavaScript -->

    <!-- Select Chosen -->


    <!-- DataTables JavaScript -->
</div>







</body>
<script src="http://harvesthq.github.io/chosen/chosen.jquery.js"></script>
<script>
    $(function() {
        $('.chosen-select').chosen({max_selected_options: 3});
        $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
    });
</script>
</html>
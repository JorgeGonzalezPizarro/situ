<link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">
<script src="/js/jquery-3.3.1.min.js"></script>

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">


        <!-- Post Content Column -->
        <div class="col-lg-12">
            <h1 class="mt-4" style="padding-left: 15px"> Calificaciones  <?php if(Sentinel::inRole('Inv') ||Sentinel::inRole( 'Prof')): ?> de <?php echo e($alumno->first_name); ?>

                {{--<?php--}}
                
                
                
                    {{--<?php--}}
                    
                    
                    
                            
                    
                <?php endif; ?> </h1>
            <hr><hr>


        </div>
        <!-- Title -->
        <?php if(!empty($calificaciones)): ?>

            <div class="col-md-12">
                <div class="col-md-12">
                    <div class="table-responsive" style="overflow-x: hidden">
                        <table id="hechos" class="mdl-data-table" cellspacing="0" width="100%">

                            <thead>
                            <tr>
                                <th style="">Nº</th>

                                <th>Grado</th>
                                <th>Calificacion </th>
                                <th>Curso-Asignatura</th>
                                <th>Profesor</th>
                                <th>Fecha</th>
                                <th>Creado</th>


                            </tr>
                            </thead>

                            <tbody id="clickable">

                            <?php $__currentLoopData = $calificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="" style="cursor: pointer">
                                    <td id="id" ><?php echo e($calif->id); ?></td>

                                    <td id="id"><?php echo $calif->calificaciones()->get()->first()->grado; ?></td>
                                    <td id="click"><?php echo e($calif->calificaciones()->get()->first()->calificacion); ?></td>
                                    <td id="click"><?php echo e($calif->calificaciones()->get()->first()->curso); ?></td>
                                    <td id="click"><?php echo e($calif->calificaciones()->get()->first()->profesor); ?></td>
                                    <td id="click"><?php echo e($calif->fecha_inicio); ?></td>
                                    <td id="click"><?php echo e($calif->created_at); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                    </div>

                </div>
                </div>

            </div>


        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                    <hr>
                    <div class="col-md-12">
                        <ul class="list-group">


                            <li class="list-group-item text-muted" style="text-align: center" contenteditable="false">No existen datos</li>


                        </ul></div></div></div>
    <?php endif; ?>

    <!-- /.row -->

    </div>

    <!-- /.container -->
<?php $__env->stopSection(); ?>


<script>

    $(document).ready(function () {





        var url = "/Alumno";

        var tr = $('#clickable');
        var table = $('#hechos').DataTable({


            "scrollX": false,

            "language": {
                "lengthMenu": "Ver _MENU_ Número de registros por página",
                "zeroRecords": "No encontrado",
                "info": "Página  _PAGE_ de  _PAGES_",
                "infoEmpty": "No hay registros disponibles",
                "infoFiltered": "(filtered from _MAX_ Total de usuarios)",
                "paginate": {
                    "first": "Primero",
                    "previous": "Anterior",
                    "next": "Siguiente",
                    "last": "Último"
                },
                "search": "Buscar &nbsp;:",

            }
        });
        $('#clickable').on('click', '#click', function () {

            var data = table
                .rows()
                .data();
            var cData = table.cell(this).data();
            var data = table.row(this).data();
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');


            $.ajax({
                type: "get",
                url: "<?php echo e(route('showHecho')); ?>",
                datatype: "json",
                encode: true,
                data: {
                    id: data[0],
                    _token: CSRF_TOKEN
                },
                success: function (response) {
                    window.location.href = "<?php echo e(url('Situ/public')); ?>" + "/" + response['id'] + "/"+response['categoria_id'];
                    console.log("aa+ " + response);

                },
                error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(JSON.stringify(jqXHR));
                    console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
                }
            });


        });
        $('#fraseButton').on('click', function () {
            var data = $('#contenido').val();
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

            $.ajax({
                type: "post",
                url: "<?php echo e(route('fraseguia')); ?>",
                encode: true,
                data: {
                    contenido: data,
                    categoria_id: 3,
                    _token: CSRF_TOKEN

                },
                success: function (response) { // What to do if we succeed
                    window.location.href = "<?php echo e(route('alumnoDashboard')); ?>";

                },
                error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(JSON.stringify(jqXHR));
                    console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
                }
            });


        });
    });

</script>
<?php echo $__env->make('layouts.layoutFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <p>Page: admin.post.create</p>
    <ol class="breadcrumb">
        <li>
        </li>
        <li class="active">
            <i class="fa fa-plus-square"></i> Create
        </li>
    </ol>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php echo Form::open(array('route' => 'guardar_Hecho', 'method' => 'POST', 'files' => true )); ?>


            <h2 class="">Create a new Post</h2>

            <div class="form-group">
                <?php echo Form::label('title', 'Post Title'); ?>

                <?php echo Form::text('titulo_hecho', Input::old('titulo_hecho'), array('class' => 'form-control', 'placeholder' => 'Title')); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('Tipo de Hecho', 'Tipo de Hecho'); ?>


                <?php echo e(Form::radio('tipo_hecho', 'Trabajo académico')); ?><br>
                <?php echo e(Form::radio('tipo_hecho', 'Calificaciones')); ?>

                <?php echo e(Form::radio('tipo_hecho', 'Recuerdos')); ?>

                <?php echo e(Form::radio('tipo_hecho', 'Frases guía')); ?>

                <?php echo e(Form::radio('tipo_hecho', 'Reflexiones')); ?>

                <?php echo e(Form::radio('tipo_hecho', 'Portafolios profesional ')); ?>

                <?php echo e(Form::radio('tipo_hecho', 'Proyectos de investigación')); ?>


            </div>
            <div class="form-group">
                <?php echo Form::label('slug', 'Post slug'); ?>

                <?php echo Form::text('proposito', Input::old('proposito'), array('class' => 'form-control', 'placeholder' => 'Proposito')); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('image', 'Upload Image'); ?>

                <?php echo Form::file('imagen'); ?>

            </div>
            <div class="form-group">

                <?php echo Form::select('curso', array('1' => '1º', '2' => '2º' , '3' => '3º' , '4' => '4º' ,'otro' => 'OTRO'));; ?>

            </div>
            <div class="form-group" style="">
                <?php echo Form::label('tags', 'Link tags'); ?>

                <?php echo Form::text('evidencia', Input::old('evidencia'), array('class' => 'form-control', 'placeholder' => 'Evidencia')); ?>


                <?php echo Form::select('tags', array('IMAGEN' => 'imagen', NULL, ['class' => 'form-control chosen-select', 'name' => 'tags[]', 'multiple tabindex' => 6])); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('text', 'Text as Markdown'); ?> Click <a href="https://blog.ghost.org/markdown/" target="_blank" >here</a> to get some tips on how to write Markdown.
                <?php echo Form::textarea('contenido', Input::old('contenido')); ?>

            </div>

            <?php echo Form::submit('Create Post', array('class'=>'btn btn-primary')); ?>


            <?php echo Form::close(); ?>


        </div><!-- /.col-md-12 -->
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!-- /.row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var simplemde = new SimpleMDE({
            element: document.getElementById("text"),
            renderingConfig: {
                singleLineBreaks: false,
                codeSyntaxHighlighting: true,
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
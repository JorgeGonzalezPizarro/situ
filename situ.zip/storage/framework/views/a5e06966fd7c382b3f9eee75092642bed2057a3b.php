<script src="/js/jquery-3.3.1.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.js"></script>
<style>
    input {
        border: 0 !important;
        border-bottom: 1px solid #ddd !important;
        padding: 7px !important;
        width:  80%;
    }
</style><?php $__env->startSection('content'); ?>

    <div class="container target">
        <div class="row">


        </div>




        <div class="row">
            <div class="col-sm-12">

                <nav class="navbar navbar-light" style="margin-left: 15px; margin-right: 15px;background-color: #e3f2fd;">

                    <div class="collapse navbar-collapse" id="navbarColor03" style="padding-left: 0px !important;">
                        <ul class="nav navbar-nav ">
                            <li class="nav-item active">
                                <a class="nav-link" href="<?php echo e(route('misDatos')); ?>">Personales <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('misDatosAcademicos')); ?>">Académicos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('misDatosLaborales')); ?>">Profesionales</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('invitar')); ?>">Invitados</a>
                            </li>

                        </ul>
                    </div>

                </nav></div>
            <?php echo e(Form::open(array('route' => 'invitar', 'class' => 'form-style-8','files' => true))); ?>





            <div class="col-sm-12" style="" contenteditable="false">

                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xs-offset-0 col-sm-offset-0 col-md-offset-0 col-lg-offset-0 toppad">


                    <div class="panel panel-info">


                        <div class="panel-body">
                            <div class="row">



                                <div class=" col-md-12 col-lg-12 ">

                                    <table class="table table-user-information" id="mitabla">
                                        <div class="input-append">
                                            
                                            <?php echo Form::text('imagen', $otros_datos['img'], ['id'=>'fieldID4','class' => 'misDatos','readonly' => 'true','style'=>'display:none;' ]); ?>


                                        </div>
                                        <tbody>
                                        <tr>
                                            <td><strong class="">Nombre Invitado:</strong></td>
                                            <td><?php echo Form::text('first_name', null, ['id'=>'first_name','class' => 'misDatos' ,'required'=>'true']); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong class="">Apellido Invitado:</strong></td>
                                            <td><?php echo Form::text('last_name', null, ['id'=>'last_name','class' => 'misDatos' ,'required'=>'true']); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <div class="form-group  <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">

                                            <td><strong class="">Correo Invitado:</strong></td>
                                            <td><?php echo Form::text('email', null, ['id'=>'email','class' => 'misDatos','required'=>'true']); ?>


                                            </td>
                                                <?php echo $errors->first('email', '<div class="alert alert-danger"><p>
El correo electronico ya existe</p></div>'); ?>


                                            </div>
                                        </tr>
                                        <tr>
                                            <td><strong class="">Password:</strong></td>
                                            <td>
                                                <input class="field"  name="password" id="password" type="password" required >

                                            </td>
                                        </tr>
                                        <tr>
                                        <td><strong class=""> </strong></td>
                                        <td>

                                            <input name="password_confirmation" class="field" data-match="#new_password" data-match-error="Las contraseñas no coinciden" placeholder="Confirmar Contraseña" required   id="password_confirmation" type="password" value="">

                                        </td>
                                        </tr>
                                        <tr>
                                            <td><strong class="">Rol:</strong></td>
                                            <td>
                                            
                                                

                                                <?php echo Form::select('roles[]', ['3'=>'Profesor','4'=>'Invitado'] ,$roles, ['id'=>'roles', 'class' => 'form-control','style'=>'width:40%;']); ?>


                                            </td>
                                        </tr>
                                        <tr id="divRoles1">

                                        </tr>
                                        <tr>
                                            <?php if(Session::has('error')): ?>
                                                <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                                            <?php endif; ?>
                                            <?php if(Session::has('msg')): ?>
                                                <div class="alert alert-info"><?php echo e(Session::get('msg')); ?></div>
                                            <?php endif; ?>

                                        </tr>



                                        </tbody>

                                    </table>
                                    <div class='col-md-5' style="    margin-top: 10px;
                                      margin-left: 240px;">

                                        <?php echo Form::submit('Invitar', array('class'=>'btn btn-info ' ,'id'=>'boton' , 'style="margin-right:30px"')); ?></td>

                                    </div>

                                    <?php echo Form::close(); ?>


                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


            <div id="push"></div>
        </div>
        <div class="col-md-10">
            <table id="asignaturas"  class="mdl-data-table" cellspacing="0" width="100%">
                <?php if(isset($invitados)): ?>
                    <thead>
                    <tr>
                        <th>Invitado</th>
                        <th>Rol</th>
                        <th>Fecha Registro</th>
                        <th>Último Login</th>
                        <th>Número de Logins </th>
                        <th>Fecha Límite </th>

                    </tr>
                    </thead>

                    <tbody id="clickable">

                    <?php if(!empty($invitados)): ?>
                        
                        
                        <?php $__currentLoopData = $invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($invitado->getUsuario()->get()->first()->first_name); ?></td>
                                <td><?php echo e($invitado->rol); ?></td>
                                <td><?php echo e($invitado->getUsuario()->get()->first()->created_at); ?></td>
                                <td><?php echo e($invitado->getUsuario()->get()->first()->last_login); ?></td>
                                <td><?php echo e($invitado->numero_accesos); ?></td>
                                <td><?php echo e($invitado->fecha_limite); ?>

                                <td><a href="#myModal2" data-toggle="modal" id="<?php echo e($invitado->id); ?>" data-target="#myModal2">Cambiar me</a>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    </tbody>

            </table>


        </div>
        <div class="col-md-2">
           <span class="pull-left">  <strong></strong>
           </span> <span><p><a target="_blank" href="<?php echo e(route('logAccesos')); ?>"><button type="button" class="btn btn-raised btn-secondary">LOGS ACCESOS</button></a></p></span>

        </div>
        <footer id="footer">

        </footer>

    </div>

    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">

                <div class="modal-body">
                    <iframe width="700" height="400" src="../js/tinymce/js/tinymce/plugins/responsive_filemanager/filemanager/dialog.php?type=2&field_id=fieldID4'&fldr=" frameborder="0" style="overflow: scroll; overflow-x: hidden; overflow-y: scroll; "></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
    </div><!-- /#wrapper -->
    <!-- Modal -->
    <div class="modal fade" id="myModal2" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class='input-group date' id='datetimepicker2'>
                            <input name="fechaActualizar" id="fechaActualizar" type='text' class="form-control" />
                            <span class="input-group-addon">

                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                        </div>
                        <div class='input-group date' id='datetimepicker2'>
                            <button type="submit" id="botonActualizarFecha">Confirmar</button>

                        </div>
                    </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/moment.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
    <?php $__env->stopSection(); ?>


<script>
    $(document).ready(function () {


            var e = document.getElementById("roles");
            var strUser = e.options[e.selectedIndex].text;


                fecha_limite();

                date();



        $('#myModal2').on('shown.bs.modal',function (e) {
          var id= e.relatedTarget.id;
            $("#botonActualizarFecha").on('click',function () {
            var fecha=document.getElementById("fechaActualizar");
            var fechaActualizar=fecha.value;
            var mensaje = confirm("¿Confirma cambiar la fecha");
            if (mensaje) {


                $.ajax({
                    type: "get",
                    url: "<?php echo e(route('actualizarFecha')); ?>",
                    data: {
                        fecha: fechaActualizar,
                        id : id,
                    },
                    success: function (response) {
                   window.location.reload();
                    },
                    error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
                    console.log(jqXHR);

                    }
                });
            }


            else {

            }
            })


        });
            $('#datetimepicker2').datetimepicker({
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down"
                },
                format: 'YYYY-MM-DD',
            });


        });
        function getFormattedDate(date) {
            var day = date.getDate();
            var month = date.getMonth() + 1;
            var year = date.getFullYear().toString().slice(2);
            return day + '-' + month + '-' + year;


    }




</script>

<script type="text/javascript">
    function date() {
        $(function () {
            $('#datetimepicker1').datetimepicker({
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down"
                },
                format: 'YYYY-MM-DD',
            });


        });
      }


</script>

<script type="text/javascript">
    function fecha_limite() {
        $("#divRoles1").empty();


        var html=

            '             <td id="" class="form-group  "><strong>Fecha Límite</strong></td><td class="input-group date" id="datetimepicker1">'
            +  '<span class="input-group-addon">'
            +   '<span class="glyphicon glyphicon-calendar"></span>'
            +    ' </span>'

            +  ' <input type="text"  name="fecha_limite" required /></td>'

     +   ' </td> '  ;


        $("#divRoles1").append(html);






    }
</script>
<script>function responsive_filemanager_callback(field_id){
        console.log(field_id);

        var url=jQuery('#'+field_id).val();
        // $('#myModal').modal('hide');


        $('#myimage').attr('src', url);

    }



</script>
<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
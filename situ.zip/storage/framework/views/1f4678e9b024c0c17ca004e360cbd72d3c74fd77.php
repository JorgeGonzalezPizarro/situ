<link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Post Content Column -->
            <div class="col-lg-12">

                <!-- Title -->
                <h1 class="mt-4"><?php echo e($hecho->titulo_hecho); ?></h1>

                <!-- Author -->
                <p class="lead">
                    <a href=""><?php echo e($user-> first_name. " ". $user->last_name); ?> </a>
                </p>



                <hr>


                <?php if(!empty($hecho->ruta_imagen)): ?>
                    <img class="img-fluid rounded" style="width: 600px; height: 300px;"src="<?php echo e($hecho->ruta_imagen); ?>" alt="">
                <?php endif; ?>

                <div class="panel-body">

                    <div class="row">

                            <ul class="timeline">
                                <li>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> <?php echo e($hecho->created_at); ?></small></p>
                                        </div>
                                        <div class="timeline-body">
                                            <p style="font-size: 18px;font-family: 'Harlow Solid Italic';font-style: italic">"<?php echo e($hecho->contenido); ?>"<span> por <?php echo e($user-> first_name); ?></span></p>
                                <?php $__currentLoopData = ($hecho->getEtiqueta()->get()->all()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiquetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <p class="list-group-item text-left">
                                        <a href=" <?php echo e(url('Situ/public#'.$etiquetas->etiqueta_id)); ?>"><?php echo e($etiquetas->etiqueta_id); ?></a>
                                    </p>

                                        </div>
                                    </div>
                                </li>


                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>



            </div>

            <hr>


            <hr>
            <!-- Search Widget -->


            <!-- Side Widget -->


        </div>

    <?php if(!empty($otrosHechos)): ?>
        <!-- Post Content Column -->
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4" style="padding-left: 15px">  Relacionado con  <?php echo e($hecho->titulo_hecho); ?></h1>
                    <hr>
                    <?php $__currentLoopData = $otrosHechos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(!empty($hecho->ruta_imagen)): ?>
                            <img class="img-fluid rounded" style="width: 600px; height: 300px;"src="<?php echo e($hecho->ruta_imagen); ?>" alt="">

                        <?php endif; ?>


                    <!--left col-->
                            <ul class="timeline">
                                <li>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> <?php echo e($hecho->created_at); ?></small></p>
                                        </div>
                                        <div class="timeline-body">
                                            <p style="font-size: 18px;font-family: 'Harlow Solid Italic';font-style: italic">"<?php echo e($hecho->contenido); ?>"<span> por <?php echo e($user-> first_name); ?></span></p>
                                        </div>
                                    </div>
                                </li>


                            </ul>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

            </div>
            <!-- /.row -->

    </div>

    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">


            <div class="col-lg-12">
                <h1 class="" style="padding-left: 15px">  Proyectos de Investigación   <?php if(Sentinel::inRole('Inv') ||Sentinel::inRole( 'Prof')): ?> de <?php echo e($alumno->first_name); ?>

                    {{--<?php--}}
                    
                    
                    
                        {{--<?php--}}
                        
                        
                        
                                
                        
                    <?php endif; ?> </h1>
                <hr><hr>


            </div>


        <?php if(!empty($proyectos)): ?>

            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




                <!--left col-->
                    <?php if(count($proyectos)>1): ?>
                        <div class="col-md-4">
                            <?php else: ?>
                                <div class="col-md-12">

                                    <?php endif; ?>
                                    <ul class="list-group">

                                        <li class="list-group-item text-muted" contenteditable="false">Detalles</li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class=""><?php echo e($hecho->getCategoria()->get()->first()->categoria); ?> </strong></span><span><p><?php echo e($hecho->titulo_hecho); ?></p></span>
                                        </li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Fecha publicación </strong></span><span><p><?php echo e($hecho->created_at); ?></p></span>
                                        </li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Fecha del <?php echo e($hecho->getCategoria()->get()->first()->categoria); ?>  </strong></span><span><p><?php echo e($hecho->fecha_inicio); ?></p></span>
                                        </li>

                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Etiquetas </strong></span><span><p>
                            <?php $__currentLoopData = ($hecho->getEtiqueta()->get()->all()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiquetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <a href="#"><?php echo e($etiquetas->etiqueta_id); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p></span>
                                        </li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class=""> </strong></span>
                                            <span><p><a href=" <?php echo e(url('Situ/public')); ?>/<?php echo e($hecho->id); ?>/<?php echo e($hecho->getCategoria()->get()->first()->id); ?>" class="btn btn-info" role="button">Ver</a>
                                    </p></span>  </li>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        

                                    </ul>
                                </div>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
        </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                    <hr>
                    <div class="col-md-12">
                        <ul class="list-group">


                            <li class="list-group-item text-muted" style="text-align: center" contenteditable="false">No existen datos</li>


                        </ul></div></div></div>
        <?php endif; ?>
    </div>
    <!-- /.row -->

    </div>

    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
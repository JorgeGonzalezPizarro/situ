<link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">
    <?php $__currentLoopData = $hechos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">

            <!-- Post Content Column -->
            <div class="col-lg-8">

                <!-- Title -->
                <h1 class="mt-4"><?php echo e($hecho->titulo_hecho); ?></h1>

                <!-- Author -->
                <p class="lead">
                    by
                    <a href="#">Start Bootstrap</a>
                </p>

                <hr>

                <!-- Date/Time -->
                <p><?php echo e($hecho->fecha_inicio); ?></p>

                <hr>

                <!-- Preview Image -->

                <hr>

                <!-- Post Content -->
                <?php echo $hecho->contenido; ?>



            </div>


    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
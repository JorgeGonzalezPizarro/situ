<link href="<?php echo e(asset('chosen/bootstrap.min.css')); ?>" rel="stylesheet">

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="container">


            <!-- Post Content Column -->
            <div class="col-lg-12">
                <h1 class="mt-4" style="padding-left: 15px"> Portfolio Profesional <?php if(Sentinel::inRole('Inv') ||Sentinel::inRole( 'Prof')): ?> de <?php echo e($alumno->first_name); ?>

                    <?php
                    $img=json_decode($alumno->otros_datos,true)
                    ?>
                                                                                       <?php else: ?>
                                                                                       <?php
                                                                                       $img=json_decode($user->otros_datos,true)
                         ?>
                       
                               
                        
                    <?php endif; ?> </h1>
                <hr><hr>
            </div>
                <!-- Title -->
                <?php if(!empty($hechos) && count($hechos)>0): ?>
                        <div class="col-md-8">
                            <div class="col-md-12">
                                <ul class="list-group">


                        <?php $__currentLoopData = $hechos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hecho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <!--left col-->
                        <?php if(!is_null($hecho->laboral_id)): ?>
                                    <li class="list-group-item text-muted"><h2 class="">Experiencia Profesional </h2>
                                    </li>

                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Sector </strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->sector); ?></p></span>
                                        </li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Empresa </strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->empresa); ?></p></span>
                                        </li>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Cargo </strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->cargo); ?></p></span>
                                        </li>
                                <li class="list-group-item text-right"><span class="pull-left"><strong
                                                class="">Ubicacion </strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->ubicacion); ?></p></span>
                                </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Fecha Inicio</strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->fecha_inicio); ?></p></span>
                                    </li>
                                    <?php if( $hecho->getLaboral()->get()->first()->actual=='0'): ?>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Fecha Fin  </strong></span><span><p><?php echo e($hecho->getLaboral()->get()->first()->fecha_fin); ?></p></span>
                                        </li>

                                    <?php else: ?>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Fecha Fin</strong></span><span><p>Actualidad</p></span>
                                        </li>
                                    <?php endif; ?>
                                <?php elseif(!is_null($hecho->formacion_id)): ?>
                                    <li class="list-group-item text-muted"><h2 class="">Formacion Academica </h2>
                                    </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Centro </strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->centro); ?></p></span>
                                    </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Ubicacion </strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->ubicacion); ?></p></span>
                                    </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Titulacion </strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->titulacion); ?></p></span>
                                    </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Disciplina Academica </strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->disciplina_academica); ?></p></span>
                                    </li>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Fecha Inicio</strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->fecha_inicio); ?></p></span>
                                    </li>
                                <?php if( $hecho->getFormacion()->get()->first()->actual=='0'): ?>
                                    <li class="list-group-item text-right"><span class="pull-left"><strong
                                                    class="">Fecha Fin  </strong></span><span><p><?php echo e($hecho->getFormacion()->get()->first()->fecha_fin); ?></p></span>
                                    </li>

                                    <?php else: ?>
                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Fecha Fin</strong></span><span><p>Actualidad</p></span>
                                        </li>
                                    <?php endif; ?>

                                        <li class="list-group-item text-right"><span class="pull-left"><strong
                                                        class="">Etiquetas </strong></span><span><p>



                            <?php $__currentLoopData = ($hecho->getEtiqueta()->get()->all()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiquetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <a href=" <?php echo e(url('Situ/public#'.$etiquetas->etiqueta_id)); ?>"><?php echo e($etiquetas->etiqueta_id); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p></span>
                                        </li>


                                <?php endif; ?>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>

                        </div>
            <div class="col-md-4">
                <div class="col-md-12">
                    <ul class="list-group">

                        <li class="list-group-item text-muted" contenteditable="false">Otros datos</li>

                        <li class="list-group-item text-right"><span class="pull-left">
                                        <i class="fa fa-linkedin fa-2x"></i></span>

                            <span><p>   <a href="http://<?php echo $img['linkedin']; ?>"> Perfil en Linkedin</a></p></span></li>

                        <li class="list-group-item text-right"><span class="pull-left">  <strong>Generar CV</strong>
                                    </span> <span><p><a target="_blank" href="<?php echo e(url('Situ/public/0/5/0/cv')); ?>"><button type="button" class="btn btn-raised btn-secondary">CV</button></a></p></span></li>

                    </ul>
                </div>
            </div>




        <?php else: ?>
                    <div class="row">
                        <div class="col-md-12">
                            <hr>
                            <div class="col-md-12">
                                <ul class="list-group">


                                    <li class="list-group-item text-muted" style="text-align: center" contenteditable="false">No existen datos</li>


                                </ul></div></div></div>
                <?php endif; ?>

        <!-- /.row -->

    </div>

    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <hr class="">

    <div class="container target">
        <div class="row">
            <div class="col-md-10">
                <h1 class=""><?php echo e($user->first_name); ?>                <img style=" width: 50px;height: 50px; float: right;"  id="myimagen" src="<?php echo $otros_datos['img']; ?>">
                </h1>

                <br>
                <br>

            </div>


        <br>
            <div class="col-md-5">
                <div style="    color: #ffffff;
    background-color: #003865;
    border-color: #bce8f1;" class="panel-heading">EXPERIENCIA PROFESIONAL</div>
                <ul class="list-group">


                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Fecha  de registro </strong></span><?php echo e($user->created_at); ?> </li>
                    <li class="list-group-item text-right" style="min-height: 60px;"><span class="pull-left"><strong class="">Fecha  último acceso</strong></span><span><p><?php echo e($user->last_login); ?> </p></span></li>
                </ul>




            </div>
            <!--/col-3-->
            <div class="  col-md-5">
                <div style="    color: #ffffff;
    background-color: #003865;
    border-color: #bce8f1;" class="panel-heading">EXPERIENCIA PROFESIONAL</div>
                <ul class="list-group">



                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nombre:</strong></span>
                        <?php echo $user->first_name; ?>

                    </li>

                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Apellido:</strong></span>
                       <?php echo $user->last_name; ?>

                    </li>
                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Email:</strong></span>
                        <?php echo $user->email; ?>

                    </li>

                    <li class="list-group-item text-right"><span class="pull-left"><strong class="">Rol:</strong></span>

                        <?php echo e($user->roles()->first()->slug); ?>

                    </li>
                </ul>

</div>
            </div>


        <div class="col-md-5">
            <!--left col-->

            <div style="    color: #ffffff;
    background-color: #003865;
    border-color: #bce8f1;" class="panel-heading">EXPERIENCIA PROFESIONAL</div>

            <ul class="list-group">
                <li class="list-group-item text-muted">Actividad <i class="fa fa-dashboard fa-1x"></i>

                </li>
                <li class="list-group-item text-right"><span class="pull-left"><strong
                                class="">Hechos</strong></span> <?php echo count($hechos); ?>

                </li>
                <li class="list-group-item text-right"><span class="pull-left"><strong
                                class="">Invitados</strong></span> <?php echo count($invitados); ?>

                </li>
                <li class="list-group-item text-right"><span class="pull-left"><strong
                                class="">Profesores Invitados</strong></span> <?php echo count($profesores); ?>

                </li>

            </ul>
        </div>
            <div class="col-md-5">
                <div style="    color: #ffffff;
    background-color: #003865;
    border-color: #bce8f1;" class="panel-heading">EXPERIENCIA PROFESIONAL</div>
            <ul class="list-group">
                <li class="list-group-item text-muted"> Etiquetas <i class="fa fa-dashboard fa-1x"></i>

                </li>
                <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-left"><span class=""><strong
                                    class=""><?php echo $etiqueta->nombre; ?></strong></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $etiquetasPublic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiquetaPubli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-left"><span class=""><strong
                                    class=""><?php echo $etiquetaPubli->slug; ?></strong></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ul>

        </div>


            </div>

    </div>


        
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
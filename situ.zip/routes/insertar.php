<?php
/**
 * Created by PhpStorm.
 * User: JorgePc
 * Date: 22/01/2018
 * Time: 17:33
 */

Route::get('/', 'RegisterController@create');
